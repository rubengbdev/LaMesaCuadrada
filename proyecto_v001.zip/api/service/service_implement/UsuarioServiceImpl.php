<?php

require_once (__DIR__.'/../UsuarioService.php');
require_once(__DIR__.'/../../model/DAO/UsuarioDAO.php');

class UsuarioServiceImpl implements UsuarioService {
 
    private $dao;

    public function __construct() {
        $this->dao = new UsuarioDao();
    }




    public function obtenerUsuarioPorId($id) {
        // validar el ID del usuario
        if (!$id) {
            throw new Exception("Falta el ID del usuario");
        }

        // buscar el usuario por su ID
        $usuario = $this->dao->obtenerUsuarioPorId($id);
        if (!$usuario) {
            throw new Exception("Usuario no encontrado");
        }

        return $usuario;
    }

    public function obtenerUsuarios() {
        // validar el ID del usuario

        // buscar el usuario por su ID
        $usuarios = $this->dao->obtenerUsuarios();
        if (count($usuarios) < 1) {
            throw new Exception("No hay usuarios");
        }

        return $usuarios;
    }

    public function crearUsuario($nombre, $email, $password) {
        // validar los datos del usuario
        if (!$nombre || !$email || !$password) {
            throw new Exception("Faltan datos del usuario");
        }

        // verificar que el email no esté registrado previamente
        $usuarioExistente = $this->dao->obtenerUsuarioPorEmail($email);
        if ($usuarioExistente) {
            throw new Exception("El email ya está registrado");
        }

        // crear el nuevo usuario
        $nuevoUsuario = new Usuario($nombre, $email, $password);
        $this->dao->guardarUsuario($nuevoUsuario);
    }

    public function actualizarUsuario($id, $nombre, $email, $password) {
        // validar el ID del usuario y los nuevos datos a actualizar
        if (!$id || (!$nombre && !$email && !$password)) {
            throw new Exception("Faltan datos para actualizar el usuario");
        }

        // buscar el usuario por su ID
        $usuario = $this->dao->obtenerUsuarioPorId($id);
        if (!$usuario) {
            throw new Exception("Usuario no encontrado");
        }

        // actualizar los datos del usuario
        if ($nombre) {
            $usuario->setNombre($nombre);
        }
        if ($email) {
            $usuario->setEmail($email);
        }
        if ($password) {
            $usuario->setPassword($password);
        }
        $this->dao->actualizarUsuario($usuario);
    }

    public function eliminarUsuario($id) {
        // validar el ID del usuario
        if (!$id) {
            throw new Exception("Falta el ID del usuario");
        }

        // buscar el usuario por su ID
        $usuario = $this->dao->obtenerUsuarioPorId($id);
        if (!$usuario) {
            throw new Exception("Usuario no encontrado");
        }

        // eliminar el usuario
        $this->dao->eliminarUsuario($usuario);
    }

}