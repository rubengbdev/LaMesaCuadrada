<?php

require_once (__DIR__.'/../UsuarioService.php');
require_once(__DIR__.'/../../model/DAO/UsuarioDAO.php');

class UsuarioServiceImpl implements UsuarioService {
 
    private $dao;

    public function __construct() {
        $this->dao = new UsuarioDao();
    }

    public function obtenerUsuarioPorId($id) {
        // validar el ID del usuario
        if (!$id) {
            throw new Exception("Falta el ID del usuario");
        }

        // buscar el usuario por su ID
        $usuario = $this->dao->obtenerUsuarioPorId($id);
        if (!$usuario) {
            throw new Exception("Usuario no encontrado");
        }

        return $usuario;
    }

    public function obtenerUsuarios() {
        // validar el ID del usuario

        // buscar el usuario por su ID
        $usuarios = $this->dao->obtenerUsuarios();
        if (count($usuarios) < 1) {
            throw new Exception("No hay usuarios");
        }

        return $usuarios;
    }

    public function crearUsuario($nombre, $email, $password, $tipo) {
        // validar los datos del usuario
        if (!$nombre || !$email || !$password || !$tipo) {
            throw new Exception("Faltan datos del usuario");
        }

        // verificar que el email no esté registrado previamente
        $usuarioExistente = $this->dao->obtenerUsuarioPorEmail($email);
        if ($usuarioExistente != null) {
            throw new Exception("Ya existe un usuario con este correo electrónico");
        }

        // Obtener la fecha actual del servidor
        $fechaCreacion = date("Y-m-d H:i:s");
    
        // Generar un salt aleatorio para la contraseña
        $salt = random_bytes(16);
    
        // Concatenar el salt con la contraseña
        $contraseñaConSalt = $contraseña . $salt;
    
        // Cifrar la contraseña usando el algoritmo bcrypt y el salt generado
        $contraseñaCifrada = password_hash($contraseñaConSalt, PASSWORD_BCRYPT);
    
        try {

            $this->dao->createUsuario($nombre,$email,$password,$tipo);

            // // Si no existe un usuario con el mismo correo electrónico, insertar el nuevo usuario en la tabla correspondiente
            // $sql = "INSERT INTO usuarios (nombre, contraseña, email, tipo, fecha_creacion)
            //         VALUES (:nombre, :contraseña, :email, :tipo, :fechaCreacion)";
            // $consulta = $this->pdo->prepare($sql);
            // $consulta->bindParam(':nombre', $nombre);
            // $consulta->bindParam(':contraseña', $contraseñaCifrada);
            // $consulta->bindParam(':email', $email);
            // $consulta->bindParam(':tipo', $tipo);
            // $consulta->bindParam(':fechaCreacion', $fechaCreacion);
            // $consulta->execute();

            // Obtener el ID del usuario recién creado
            $id = $this->pdo->lastInsertId();

            // Devolver el ID del usuario
            return $id;
        } catch (PDOException $e) {
            // Manejar cualquier excepción que pueda ocurrir al ejecutar la consulta
            echo "Error al crear el usuario: " . $e->getMessage();
        }
    }

    public function actualizarUsuario($id, $nombre, $email, $password) {
        // validar el ID del usuario y los nuevos datos a actualizar
        if (!$id || (!$nombre && !$email && !$password)) {
            throw new Exception("Faltan datos para actualizar el usuario");
        }

        // buscar el usuario por su ID
        $usuario = $this->dao->obtenerUsuarioPorId($id);
        if (!$usuario) {
            throw new Exception("Usuario no encontrado");
        }

        // actualizar los datos del usuario
        if ($nombre) {
            $usuario->setNombre($nombre);
        }
        if ($email) {
            $usuario->setEmail($email);
        }
        if ($password) {
            $usuario->setPassword($password);
        }
        $this->dao->actualizarUsuario($usuario);
    }

    public function eliminarUsuario($id) {
        // validar el ID del usuario
        if (!$id) {
            throw new Exception("Falta el ID del usuario");
        }

        // buscar el usuario por su ID
        $usuario = $this->dao->obtenerUsuarioPorId($id);
        if (!$usuario) {
            throw new Exception("Usuario no encontrado");
        }

        // eliminar el usuario
        $this->dao->eliminarUsuario($id);
    }

}