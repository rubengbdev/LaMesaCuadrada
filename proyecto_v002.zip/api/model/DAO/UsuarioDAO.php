<?php

require_once("../model/Usuario.php");

class UsuarioDAO {

    private $pdo;

    public function __construct() {
        $dsn = "mysql:host=" . "db" . ";dbname=" . "mesa_cuadrada";
        $this->pdo = new PDO($dsn, "root", "root");
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }


    public function createUsuario(Usuario $usuario) {

        $stmt = $this->pdo->prepare('INSERT INTO usuario (nombre, email, password, tipo) VALUES (?, ?, ?, ?)');
        $stmt->execute([$usuario->getNombre(), $usuario->getEmail(), $usuario->getPassword(), $usuario->getFechaCreacion]);
        return $this->pdo->lastInsertId();

    }

    public function obtenerUsuarioPorId($id) {

        $stmt = $this->pdo->prepare('SELECT * FROM usuario WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return null;
        }
        return new Usuario($row['usuario_id'], $row['usuario_nombre'], $row['usuario_email'], $row['usuario_contrasena'], $row['usuario_fecha_creacion']);

    }

    public function obtenerUsuarioPorEmail($email) {

        $stmt = $this->pdo->prepare('SELECT * FROM usuario WHERE email = ?');
        $stmt->execute([$email]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            return null;
        }
        return new Usuario($row['usuario_id'], $row['usuario_nombre'], $row['usuario_email'], $row['usuario_contrasena'], $row['usuario_fecha_creacion']);
        
    }

    public function obtenerUsuarios() {

        //meter todo en un try catch

        $stmt = $this->pdo->prepare('SELECT * FROM mesa_cuadrada.usuario');
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $usuarios = [];
            foreach ($stmt as $elemento) {
                $user = new Usuario();
                $user->setId($elemento['usuario_id']);
                $user->setNombre($elemento['usuario_nombre']);
                $user->setEmail($elemento['usuario_email']);
                $user->setContrasena($elemento['usuario_contrasena']);
                $usar->setFechaCreacion($elemento['usuario_fecha_creacion'])
                $usuarios[] = $user->toArray(); 
            }
            return $usuarios;
        } else {
            return false;
        }

    }


    // public function update(Usuario $usuario) {
    //     $stmt = $this->pdo->prepare('UPDATE usuario SET nombre = ?, email = ?, password = ? WHERE id = ?');
    //     $stmt->execute([$usuario->getNombre(), $usuario->getEmail(), $usuario->getPassword(), $usuario->getId()]);
    //     return $stmt->rowCount();
    // }

    public function eliminarUsuario($id) {
        $stmt = $this->pdo->prepare('DELETE FROM usuario WHERE id = ?');
        $stmt->execute([$id]);
        return $stmt->rowCount();
    }

}